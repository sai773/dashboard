import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule ,  HTTP_INTERCEPTORS} from '@angular/common/http';
import {HttpModule} from '@angular/http';
import {ActivatedRoute} from '@angular/router';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; // this includes the core NgIdleModule but includes keepalive providers for easy wireup
import { MomentModule } from 'angular2-moment';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NewaccountComponent } from './newaccount/newaccount.component';
import { ServiceComponent } from './service/service.component';
import { ActionComponent } from './action/action.component';
import { ViewaccontComponent } from './viewaccont/viewaccont.component';
import { DisplayServiceComponent } from './display-service/display-service.component';
import { BnNgIdleService } from 'bn-ng-idle';
import { InterceptorService } from './services/interceptor.service';
import { NewviewComponent } from './newview/newview.component';
import { FiltersPipe } from './filters.pipe';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NewaccountComponent,
    ServiceComponent,
    ActionComponent,
    ViewaccontComponent,
    DisplayServiceComponent,
    NewviewComponent,
    FiltersPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    NgIdleKeepaliveModule.forRoot(),
    MomentModule,
    NgxPaginationModule
 


  ],
  providers: [ {
    provide: HTTP_INTERCEPTORS,
    useClass: InterceptorService,
    multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
