import { Component, OnInit } from '@angular/core';
import { UserDetails,Userserv, use } from '../User';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { Router} from '@angular/router';
import { EncryptdecryptService} from '../encryptdecrypt.service'
import { from } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-viewaccont',
  templateUrl: './viewaccont.component.html',
  styleUrls: ['./viewaccont.component.css']
})
export class ViewaccontComponent implements OnInit {
public a:any;
//userList:UserDetails[]=[];
public newleave:any;
public _id:String;
public user:String;
public Firstname:String;
public LastName:String;
public CompanyName:String;
public Department:String;
public EmailAddress:String;
public PhoneNumber:String;
public MobileNumber:String;
public Language:String;
public TimeZone:string;
public Addressline1:String;
public Addressline2:String;
public City:String;
public State:String;
public Country:String;
public merchantId:String;
public id:String;
//arr:any[] = [];
//selectdata:UserDetails[]=[];
//public selectedval:any;
//selectedItem: UserDetails;
public userdetails:any;
//toggleForm:boolean = false;
public a1:String;
public newleave1:String;
public newusage:any;
public errorMsg;
public newl;
public showtime:any;
public klo:any;
public newcome:any;
public newcome1:any;
public newbolt:any;
public newbolt1:any
//public newid:any;
//pu
  constructor(private dataService : DataService,private http: HttpClient,public router: Router,public ActivatedRoute:ActivatedRoute,private AESencrypt: EncryptdecryptService ) {
  
 
   
   var tabID3 = sessionStorage.tabID3 ? sessionStorage.tabID3 : sessionStorage.tabID3 = Math.random();
this.newcome=sessionStorage.getItem(tabID3);
this.newcome1=this.AESencrypt.decrypt(JSON.parse(this.newcome));
//console.log(this.newcome1);

var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
this.newbolt= sessionStorage.getItem(tabID8);
this.newbolt1=this.AESencrypt.decrypt(JSON.parse(this.newbolt));
//console.log(this.newbolt1);

   var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1= Math.random();
   this.showtime=sessionStorage.getItem(tabID1);
   this.klo=this.AESencrypt.decrypt(JSON.parse(this.showtime));
   //console.log(this.klo);
   
    let userval: Userserv={
      log2:this.AESencrypt.encrypt(this.klo),
          
    }

           this.dataService.addUserservDetails(userval)
    .subscribe(result => {
    
    
this.userdetails=this.AESencrypt.decrypt(result);
this.newusage=JSON.parse(this.userdetails);
//console.log(this.newusage);

      this.id=this.newusage._id;
    //  console.log(this.id);
  
       this.Firstname=this.newusage.Firstname;
    
       this.LastName=this.newusage.LastName;
       this.CompanyName=this.newusage.CompanyName;
       this.Department=this.newusage.Department;
       this.EmailAddress=this.newusage.EmailAddress;
       this.PhoneNumber=this.newusage.PhoneNumber;
       this.MobileNumber=this.newusage.MobileNumber;
       this.Language=this.newusage.Language;
       this.TimeZone=this.newusage.TimeZone;
       this.Addressline1=this.newusage.Addressline1;
       this.Addressline2=this.newusage.Addressline2;
       this.City=this.newusage.City;
       this.State=this.newusage.State;
       this.Country=this.newusage.Country;
       this.newleave1=this.newusage.merchantId;

    },
    error=>this.errorMsg=error
    );
   
  }
    
  editItem(form){
    let newUser: UserDetails = {
      log17:this.AESencrypt.encrypt(this.id),

      log1:this.AESencrypt.encrypt(form.value.Firstname),
       log2:this.AESencrypt.encrypt(form.value.LastName),
      log3:form.value.CompanyName,
      log4:this.AESencrypt.encrypt(form.value.Department),
      log5:form.value.EmailAddress,
      log6:this.AESencrypt.encrypt(form.value.PhoneNumber),
      log7:this.AESencrypt.encrypt(form.value.MobileNumber),
      log8:form.value.Language,
      log9:form.value.TimeZone,
      log10:form.value.Addressline1,
      log11:form.value.Addressline2,
      log12:form.value.City,
      log13:form.value.State,
      log14:form.value.Country,
     // log15:form.value.user,
      log16:form.value.user,
    }
   
    this.dataService.updateCustomerDetails(newUser)
    .subscribe(result => {
    this.newl=result;
    if(this.newl==true)
    {
      this.router.navigate(['/action'])

    }else{
     
    
    }
    },
    error=>this.errorMsg=error
    );
    
  }
 


  ngOnInit() {
  }

}
