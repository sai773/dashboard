import { Injectable } from '@angular/core';
import {Http, Response, Headers, HttpModule} from '@angular/http';

import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Users, Userr, UserDetails ,use,Userrr,UserService,Userserv,serv, Userview} from './User';

import 'rxjs/add/operator/map';

import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs';
import { error } from '@angular/compiler/src/util';
import { User } from 'angular-idle-timeout/src/app/login/login.component';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http:HttpClient) { }
  
  getUserDetails(){
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.get('http://18.139.108.160:3000/api/myincomedetails')
    //.map(res => res.json());
  }
  
  getCustomerDetails(){
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.get('http://18.139.108.160:3000/api/myincomeusers')
  //  .map(res => res.json());
  }
  getCustomerService(){
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.get('http://18.139.108.160:3000/api/myincomeservice')
   // .map(res => res.json());
  }
  
  

  addUserDetails(newUser){
  
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post('http://18.139.108.160:3000/api/user',newUser,{headers: headers})
//.map(res=> res.json());
  }
  
  
  addUseDetails(newUser):Observable<use[]>{
  
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<use[]>('http://18.139.108.160:3000/api/use',newUser,{headers: headers}).catch(this.errorHandler2);
//.map(res=> res.json());
  }
  errorHandler2(error: HttpErrorResponse){
    return Observable.throw('Error? Please Try again Later');
  }

  addUserrDetails(newUser):Observable<Userr[]>{
  
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<Userr[]>('http://18.139.108.160:3000/api/userr',newUser,{headers: headers}).catch(this.errorHandler);
//.map(res=> res.json());
  }
  errorHandler(error: HttpErrorResponse){
    return Observable.throw('Error? Please Try again Later');
  }
  
  addUserrrDetails(newUser):Observable<UserDetails[]>{
  
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<UserDetails[]>('http://18.139.108.160:3000/api/userrr',newUser,{headers: headers}).catch(this.errorHandler3);
 }
  errorHandler3(error: HttpErrorResponse){
    return Observable.throw('Error? Please Try again Later');
  }
  
  
  addUserservDetails(newUser):Observable<Userserv[]>{
  
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<Userserv[]>('http://18.139.108.160:3000/api/userserv',newUser,{headers: headers}).catch(this.errorHandler6);
//.map(res=> res.json());
}
errorHandler6(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}



addUserviewDetails(newUser):Observable<UserDetails[]>{
  
  let headers= new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.post<UserDetails[]>('http://18.139.108.160:3000/api/userview',newUser,{headers: headers}).catch(this.errorHandler9);
//.map(res=> res.json());
}
errorHandler9(error: HttpErrorResponse){
return Observable.throw('Error? Please Try again Later');
}


addUserview1Details(newUser):Observable<User[]>{
  
  let headers= new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.post<User[]>('http://18.139.108.160:3000/api/userview1',newUser,{headers: headers}).catch(this.errorHandler13);
//.map(res=> res.json());
}
errorHandler13(error: HttpErrorResponse){
return Observable.throw('Error? Please Try again Later');
}



addservDetails(newUser):Observable<serv[]>{
  
  let headers= new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.post<serv[]>('http://18.139.108.160:3000/api/serv',newUser,{headers: headers}).catch(this.errorHandler8);
//.map(res=> res.json());
}
errorHandler8(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}
addusenameDetails(newUser):Observable<UserService[]>{
  
  let headers= new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.post<UserService[]>('http://18.139.108.160:3000/api/use1',newUser,{headers: headers}).catch(this.errorHandler10);
//.map(res=> res.json());
}
errorHandler10(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}
 


addCustomerDetails(newUser):Observable<UserDetails[]>{

    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<UserDetails[]>('http://18.139.108.160:3000/api/userDetails',newUser,{headers: headers}).catch(this.errorHandler1);
//.map(res=> res.json());
  }
  errorHandler1(error: HttpErrorResponse){
    return Observable.throw('Error? Please Try again Later');
  }
 
 
 
  addCustomerService(newUser):Observable<UserService[]>{
    let headers= new HttpHeaders();
    headers.append('Content-Type','application/json');
    return this.http.post<UserService[]>('http://18.139.108.160:3000/api/userService',newUser,{headers: headers}).catch(this.errorHandler5);
//.map(res=> res.json());
  }
  errorHandler5(error: HttpErrorResponse){
    return Observable.throw('Error? Please Try again Later');
  }
  




  
  deleteShoppingItem(id)
{
  return this.http.delete('http://18.139.108.160:3000/api/removers/'+id)
 // .map(res => res.json());

}
deleteCustomerDetails(id)
{
  return this.http.delete('http://18.139.108.160:3000/api/removersof/'+id)
//  .map(res => res.json());

}
deleteCustomerService(id)
{
  return this.http.delete('http://18.139.108.160:3000/api/removersofservice/'+id)
  //.map(res => res.json());

}


updateCustomerDetails(newUser):Observable<UserDetails[]>{
  let headers =new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.put<UserDetails[]>('http://18.139.108.160:3000/api/updatemycontents/'+newUser._id, newUser,{headers: headers}).catch(this.errorHandler7);
 // .map(res => res.json());
}
errorHandler7(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}


updateCustomerService(newUser):Observable<UserService[]>{
  let headers =new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.put<UserService[]>('http://18.139.108.160:3000/api/updateeverything/'+newUser._id, newUser,{headers: headers}).catch(this.errorHandler15);
//  .map(res => res.json());
}
errorHandler15(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}

updateCustomer(newUser):Observable<UserService[]>{
  let headers =new HttpHeaders();
  headers.append('Content-Type','application/json');
  return this.http.put<UserService[]>('http://dashboard.server:3000/api/updatee/'+newUser._id, newUser,{headers: headers}).catch(this.errorHandler16);
//  .map(res => res.json());
}
errorHandler16(error: HttpErrorResponse){
  return Observable.throw('Error? Please Try again Later');
}

}
