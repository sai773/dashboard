import { Component, OnInit } from '@angular/core';
import { UserDetails, UserService, Users, Userrr } from '../User';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { Router } from '@angular/router';
import { EncryptdecryptService} from '../encryptdecrypt.service'
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent implements OnInit {
  userList: UserDetails[]=[];
  userList1: Users[]=[];
  public a:string;
  public newleave:string;
  public merchant:String;
  public merchantId:string;
  public consumerkey:String;
  public consumerkey1:String;
  public newcome:any;
  public newcome1:any;

  public newleave1:string;
  public a1:any;
  public serv:any;
  public serv1:any;
  public newl;
  public errorMsg;
  public newbolt:any;
  public newbolt1:any
  public codeGenerated = '';
  public codeGenerated1 = '';
  constructor(private dataService : DataService,private http: HttpClient,private router: Router,public ActivatedRoute:ActivatedRoute ,private AESencrypt: EncryptdecryptService ) {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz';
  
    const stringLength = 15;
    let randomstring = '';
   
    for (let i = 0; i < stringLength; i++) {
    const rnum = Math.floor(Math.random() * chars.length);
  

    randomstring += chars.substring(rnum, rnum + 1);
   // ramndomtring1 += chars1.substring(rnum1, rnum1 + 1);
    }
    this.codeGenerated = randomstring;




    const chars1= 'abcdefghiklmnopqrstuvwxyz012345789CDEFGHIJKLMNOPQRSTUVWXTZ '
    let ramndomtring1 ='';
    for (let i = 0; i < stringLength; i++) {
      const rnum1 = Math.floor(Math.random() * chars1.length);
      ramndomtring1 += chars1.substring(rnum1, rnum1 + 1);

    }
    this.codeGenerated1=  ramndomtring1;




 
var tabID3 = sessionStorage.tabID3 ? sessionStorage.tabID3 : sessionStorage.tabID3 = Math.random();
this.newcome=sessionStorage.getItem(tabID3);
this.newcome1=this.AESencrypt.decrypt(JSON.parse(this.newcome));


 var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1 = Math.random();
 this.a=sessionStorage.getItem(tabID1);
this.a1=this.AESencrypt.decrypt(JSON.parse(this.a));

var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
this.newbolt= sessionStorage.getItem(tabID8);
this.newbolt1=this.AESencrypt.decrypt(JSON.parse(this.newbolt));

  let userval: Userrr={
    
    log2:this.AESencrypt.encrypt(this.a1),
       
          }
           this.dataService.addUserrrDetails(userval).subscribe(users=>{
            this.serv=this.AESencrypt.decrypt(users);

    },
    error=>this.errorMsg=error
           );
         
         this.consumerkey=this.codeGenerated;
       
      this.consumerkey1=this.codeGenerated1;
       
          
      
  }

   
   
 

  getCustomerssService(form){
    let newUser: UserService={
     // log1:this.AESencrypt.encrypt(this.newleave1),
     log2:this.AESencrypt.encrypt(this.a1),
      
     log3:this.AESencrypt.encrypt( form.value.ServiceName),
     log4: this.AESencrypt.encrypt(form.value.ServiceDesc),
     log5:this.AESencrypt.encrypt(form.value.ServiceType),
     log6:this.AESencrypt.encrypt(JSON.stringify(form.value.Country)),
     log7:this.AESencrypt.encrypt(JSON.stringify(form.value.txtAccessperiod)),
    log8:this.AESencrypt.encrypt(form.value.ddlAccessperiod),

     log9:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackpr1)),
     log10:this.AESencrypt.encrypt(JSON.stringify(form.value.txtFallbackperiod1)),
     log12:this.AESencrypt.encrypt(form.value.ddlFallbackperiod1),

     log13:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackpr2)),
     log14:this.AESencrypt.encrypt(JSON.stringify(form.value.txtFallbackperiod2)),
     log15:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackperiod2)),


    log16:this.AESencrypt.encrypt(JSON.stringify(form.value.txtfreetrail)),
     log17:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlfreetrailperiod)),

    log18:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlTps)),

    log19:this.AESencrypt.encrypt(form.value.ServiceimgUrl),
     log20:this.AESencrypt.encrypt(form.value.RedirectionUrl),
    log21:this.AESencrypt.encrypt(form.value.CallbackUrl),
    log22:this.AESencrypt.encrypt( form.value.SerValidationUrl),
     log23:this.AESencrypt.encrypt(form.value.SerUnSubSCode),
     log24:this.AESencrypt.encrypt(form.value.SerUnsubId),
    log25:this.AESencrypt.encrypt(form.value.MHelplineno),

      log26:this.AESencrypt.encrypt(form.value.MSupEmailid),
     log27:this.AESencrypt.encrypt(form.value.ReceiptMessage),
      log28:this.AESencrypt.encrypt(form.value.WelcomeMessage),
     log29:this.AESencrypt.encrypt(form.value.NotificationMessage),
      log30:this.AESencrypt.encrypt(form.value.UnSubMessage),

      log31:this.AESencrypt.encrypt(form.value.ServiceRoutingSettings),
   
      log32:this.AESencrypt.encrypt(this.consumerkey),
      log33:this.AESencrypt.encrypt(this.consumerkey1),
      log34:this.AESencrypt.encrypt(this.serv),
    
  
  
       }
  
  this.dataService.addCustomerService(newUser)
  .subscribe(user => {this.newl=user;
    if(this.newl==true){
      this.router.navigate(['/action']);
    }
    else{
   
    }
  
   
  
     
    
  
  },
  error=>this.errorMsg=error);
  
  }
  




  ngOnInit() {
  }

}
