$(document).ready(function(){

	$('#banner .tab').click(function(){
		$('#notification-list').slideToggle('fast');
		$(this).toggleClass('active-tab'); return false;
	});
	
	
	$('.numeric').keyup(function(){
		$(this).val(	String($(this).val()).replace(/[^0-9]/i, "") ); // numeric
		//if (String(type).match("alphanum")) 	$(t).val(	String($(t).val()).replace(/[^A-Za-z0-9]/i, "")); // alphanumeric
	
	});
	
	$('.alphanumeric').keyup(function(){
		$(this).val(	String($(this).val()).replace(/[^A-Za-z0-9]/i, "" ) ); // alphanumeric
	
	});
	 
});// doc ready
   
	







