import { Component } from '@angular/core';
import { BnNgIdleService } from 'bn-ng-idle';
import {ActivatedRoute} from '@angular/router';
import { Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dialog-front';
  constructor(private bnIdle: BnNgIdleService,private router: Router,private route:ActivatedRoute ) { 
    this.bnIdle.startWatching(500).subscribe((res) => {
      if(res) {
       this.router.navigate(['/login']);
       sessionStorage.clear();
   //   console.log("true");
      }
    })
  
}
}
