import { Component, OnInit } from '@angular/core';
import { Users, Userr, Usernew } from '../User';
import { UserDetails } from '../User';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { EncryptdecryptService } from '../encryptdecrypt.service';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { Router} from '@angular/router';

import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [DataService]
})
export class LoginComponent implements OnInit {
public Userr=[];
userList1: UserDetails[]=[];
msg: string = null;
showMsg: boolean = false;
public errorMsg;
public name="yes";
public new1:any;
public new2:any;
public new3:any;
public nelist:any;
public nelist1:any;


 public newleave:any;
  constructor(private dataService : DataService,private http: HttpClient,private router: Router,private route:ActivatedRoute , private AESencrypt: EncryptdecryptService ) {
    var tabID7 = sessionStorage.tabID7 ? sessionStorage.tabID7 : sessionStorage.tabID7 = Math.random();
 this.nelist= sessionStorage.getItem(tabID7);

  
  var tabID5 = sessionStorage.tabID5 ? sessionStorage.tabID5 : sessionStorage.tabID5 = Math.random();
  
  this.new2 = sessionStorage.getItem(tabID5);

 if(this.new2==null||this.nelist==null){

 }else{

 

  this.new3=this.AESencrypt.decrypt(JSON.parse(this.new2));
  this.nelist1=this.AESencrypt.decrypt(JSON.parse(this.nelist));

 } 


 let newUser: Usernew = {
  log1:this.AESencrypt.encrypt(this.nelist1),
   log3: this.AESencrypt.encrypt(this.new3),
 }
 this.dataService.updateCustomer(newUser).subscribe(users=>{

 },
 error=> this.errorMsg = error
 );






   sessionStorage.clear();

   
   }

  getUsers(form){
    let userval: Userr={log1:this.AESencrypt.encrypt(form.value.emailAddress),
      log2:this.AESencrypt.encrypt(form.value.password),
      }


       this.dataService.addUserrDetails(userval).subscribe(users=>{
         this.newleave=users;
      //   this.new1=users;
        
      
        if(this.newleave==true)
        {
       //   console.log('true');
         // this.router.navigateByUrl('/action',{state:{coma:userval.emailAddress}});
       //  this.router.navigate(['/action']);
        // this.msg = 'success';
      //  }
      //  else{
       //   console.log('false');
       ///  if(this.newleave==false){
          //this.router.navigateByUrl('/newaccount',{state:{coma:userval.emailAddress}});
      //  this.router.navigate(['/newaccount']);
   
      //   }
          
            
              this.router.navigate(['newview']);
        }
            else{
         console.log('err');
       
         this.showMsg= true;
  
        }
      },

      
        error=> this.errorMsg = error
        
        );
   
     
     
      var tabID = sessionStorage.tabID ? sessionStorage.tabID : sessionStorage.tabID = Math.random();
      sessionStorage.setItem(tabID,JSON.stringify(userval.log1));
  

     
     
   

  
       
     
       
      }
  
     
 

  ngOnInit() {
   
  }

}
