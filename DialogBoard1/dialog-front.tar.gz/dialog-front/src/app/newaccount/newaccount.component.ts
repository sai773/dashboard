import { Component, OnInit } from '@angular/core';
import { UserDetails,use } from '../User';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import { EncryptdecryptService} from '../encryptdecrypt.service' ;
import { HttpClient } from  '@angular/common/http';
import { Router} from '@angular/router';
import { from } from 'rxjs';
import * as uuid from 'uuid';
@Component({
  selector: 'app-newaccount',
  templateUrl: './newaccount.component.html',
  styleUrls: ['./newaccount.component.css']
})
export class NewaccountComponent implements OnInit {
  userList: UserDetails[]=[];
  public  newleave:any;
  public newl:any;
  public  new:String;
  public like:String;
  public newleave1:String;
  public new1:String;
 public newmerchant:String;
 showMsg: boolean = false;
 public errorMsg;
 public newcome:any;
 public newcome1:any;
 CurrentTime: any;
 public newbolt:any;
 public newbolt1:any;
 public codeGenerated = ''
  constructor(private dataService : DataService,private http: HttpClient,public router: Router , private AESencrypt: EncryptdecryptService ) {
  
   
      const chars = '0123456789';
      const stringLength = 8;
      let randomstring = '';
      for (let i = 0; i < stringLength; i++) {
      const rnum = Math.floor(Math.random() * chars.length);
      randomstring += chars.substring(rnum, rnum + 1);
     }
      this.codeGenerated = randomstring;
     
    // console.log(this.codeGenerated);
     
   
  
 var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1 = Math.random();
  this.newleave=sessionStorage.getItem(tabID1);
  this.newmerchant=this.codeGenerated;

 var tabID3 = sessionStorage.tabID3 ? sessionStorage.tabID3 : sessionStorage.tabID3 = Math.random();
  this.newcome=sessionStorage.getItem(tabID3);
  this.newcome1=this.AESencrypt.decrypt(JSON.parse(this.newcome));

  var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
this.newbolt= sessionStorage.getItem(tabID8);
this.newbolt1=this.AESencrypt.decrypt(JSON.parse(this.newbolt));

   }
   

getCustomersDetails(form){

  let newUser: UserDetails={
   
    log1:this.AESencrypt.encrypt(form.value.Firstname),
    log2:this.AESencrypt.encrypt(form.value.LastName),
    log3:this.AESencrypt.encrypt(form.value.CompanyName),
    log4:this.AESencrypt.encrypt(form.value.Department),
    log5:this.AESencrypt.encrypt(form.value.EmailAddress),
    log6:this.AESencrypt.encrypt(form.value.PhoneNumber),
    log7:this.AESencrypt.encrypt(form.value.MobileNumber),
    log8:this.AESencrypt.encrypt(form.value.Language),
    log9:this.AESencrypt.encrypt(form.value.TimeZone),
    log10:this.AESencrypt.encrypt(form.value.Addressline1),
    log11:this.AESencrypt.encrypt(form.value.Addressline2),
    log12:this.AESencrypt.encrypt(form.value.City),
    log13:this.AESencrypt.encrypt(form.value.State),
    log14:this.AESencrypt.encrypt(form.value.Country),
  //  log15:this.AESencrypt.encrypt(this.newleave1),
    log16:this.AESencrypt.encrypt(this.newmerchant),



     }


    
this.dataService.addCustomerDetails(newUser)
.subscribe(user => {
 
    console.log(user);

this.newl=user;

if(this.newl==true){

//this.router.navigateByUrl('/service',{state:{coma:this.newleave,bima:this.AESencrypt.encrypt(this.newmerchant)}});
this.router.navigate(['/newview']);
this.showMsg= true;
}
else{
  this.showMsg= false;

}

  

  
},
error=> this.errorMsg = error);
var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1 = Math.random();
sessionStorage.setItem(tabID1,JSON.stringify(newUser.log16));
    //console.log(tabID1);
}


  ngOnInit() {
    

  }

}
