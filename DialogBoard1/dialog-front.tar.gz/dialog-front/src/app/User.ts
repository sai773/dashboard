export class Users{
    //_id? : String;
   log1: String;
    log2 : String;
    logs:String;
EmailAddress:String;
PhoneNumber:String;
   
}

export class Userr{
    //_id? : String;
    log1: String;
    log2 : String;
   
    
}
export class Userrr{
    //_id? : String;
    log2: String;
   // logs: String;
   
    
}
export class Usernew{
    //_id? : String;
    log1:String;
    log3: String;
   // logs: String;
   
    
}
export class Userview{
    //_id? : String;
    log1: String;
   // logs: String;
   
    
}
export class Userview1{
    //_id? : String;
    log1: String;
   // logs: String;
   
    
}
export class Userserv{
    //_id? : String;
    log2: String;
  //  logs: String;
   
    
}
export class serv{
    //_id? : String;
    log2: String;
   // logs: String;
   
    
}
export class use{
    //_id? : String;
    log1: String;
   // merchantId : String;
   
    
}

export class use1{
    //_id? : String;
    log2: String;
   // merchantId : String;
   
    
}




export class UserDetails{
    log17?: any;

   // log15:String;
    log1:String;
    log2:String;
    log3:String;
    log4:String;
    log5:String;
    log6:String;
    log7:String;
    log8:String;
log9:string;
    log10:String;
    log11:String;
    log12:String;
    log13:String;
    log14:String;
    log16:String;
}
export class UserService{
   //_id?: String;
  log1?:String;
    log2:String;
    log3: String;
    log4: String;
    log5: String;
    log6:String;
    log7:String;
    log8:String;

    log9:String;
  
    log10:String;
    log12:String;
   
    log13:String;
    log14:String;
    log15:String;


    log16:Number;
    log17:String;

    log18:String;

    log19: String;
    log20: String
    log21: String;
    log22: String;
    log23:String;
    log24:String;
    log25: Number;
    log26: String;
    log27: String;
    log28:String;
    log29:String;
    log30:String;
    log31:String;
    log32:String;

  log33:String;
  log34:String;

}