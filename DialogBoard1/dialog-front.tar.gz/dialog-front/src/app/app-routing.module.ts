import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NewaccountComponent } from './newaccount/newaccount.component';
import { ServiceComponent } from './service/service.component';
import {ActivatedRoute} from '@angular/router';
import { ActionComponent } from './action/action.component';
import { ViewaccontComponent } from './viewaccont/viewaccont.component';
import { DisplayServiceComponent } from './display-service/display-service.component';
import { NewviewComponent } from './newview/newview.component';

const ROUTES: Routes = [

  {path:'login',component:LoginComponent},
  {path:'newaccount',component:NewaccountComponent},
 
  {path:'service',component:ServiceComponent},
  {path:'action',component:ActionComponent},
  {path:'viewaccont',component:ViewaccontComponent },
  {path:'display-service',component:DisplayServiceComponent},
  {path:'newview',component:NewviewComponent}

    ];

@NgModule({
  imports: [RouterModule.forRoot(ROUTES)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
