import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class EncryptdecryptService {
  secretKey = "YourSecretKeyForEncryption&Descryption";

  constructor() { }
  encrypt(value : any) : any{
    return CryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();
  }

  decrypt(textToDecrypt : any){
    return CryptoJS.AES.decrypt(textToDecrypt, this.secretKey.trim()).toString(CryptoJS.enc.Utf8);
  }

  //encrypt1(value : any): any{
    //return CryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();
  //}

}
