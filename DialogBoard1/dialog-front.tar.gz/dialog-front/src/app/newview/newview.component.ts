import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { EncryptdecryptService} from '../encryptdecrypt.service'
import { UserDetails, UserService, Users, Userrr,use,Userview,Userview1 } from '../User';
import { HttpClient } from  '@angular/common/http';
@Component({
  selector: 'app-newview',
  templateUrl: './newview.component.html',
  styleUrls: ['./newview.component.css']
})
export class NewviewComponent implements OnInit {
  public leave:string;
  public new1:string;
  public leave1:string;
  public userList:any;
  public user:any;
  public new11:any;
  public new:any;
  public hlouser:any;
  public a2:any;
  public a3:any;
  public a4:any;
  public a5:any;
  public a6:any;
  public a7:any;
  public a8:any;
  public a9:any;
  public errorMsg;
  public searchTerm:any;
  public items:any;
public newtime:any;
public user1:any;
searchText;

  toggleBool: boolean=true;
  public selectedEntry;
  public showtime:any;



 
  config: any;
  collection = { count: 1000, data: [] };


  constructor(private dataService : DataService,private http: HttpClient,public router: Router,public ActivatedRoute:ActivatedRoute,private AESencrypt: EncryptdecryptService) { 
   var tabID = sessionStorage.tabID ? sessionStorage.tabID : sessionStorage.tabID = Math.random();
 
  this.leave=sessionStorage.getItem(tabID);
  
  this.leave1=this.AESencrypt.decrypt(JSON.parse(this.leave));




  let userval11: Userview1={
  log1:this.AESencrypt.encrypt(this.leave1),
}
this.dataService.addUserview1Details(userval11)
  .subscribe(result => {

    this.hlouser=this.AESencrypt.decrypt(result);
  
    this.a2=JSON.parse(this.hlouser);
    this.a3=this.a2.Name;
    this.a6=this.a2._id;
     this.a8=this.a2.last_login;

   
  
   this.a7=this.AESencrypt.encrypt(this.a6);
   var tabID7 = sessionStorage.tabID7 ? sessionStorage.tabID7 : sessionStorage.tabID7 = Math.random();
    sessionStorage.setItem(tabID7,JSON.stringify(this.a7));

  
    this.a9=this.AESencrypt.encrypt(this.a8);
    var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
    sessionStorage.setItem(tabID8,JSON.stringify(this.a9));


    this.a5=this.AESencrypt.encrypt(this.a2.Name);
    var tabID3 = sessionStorage.tabID3 ? sessionStorage.tabID3 : sessionStorage.tabID3 = Math.random();
    sessionStorage.setItem(tabID3,JSON.stringify(this.a5));
  
  
  
    this.a4=this.AESencrypt.encrypt(this.a2.creation_date);
    var tabID5 = sessionStorage.tabID5 ? sessionStorage.tabID5 : sessionStorage.tabID5 = Math.random();
    sessionStorage.setItem(tabID5,JSON.stringify(this.a4));
   // console.log(sessionStorage.getItem(tabID5));
  },
  error=>this.errorMsg=error
  );


 

  let userval: Userview={
    log1:this.AESencrypt.encrypt(this.leave1),
        
  }

  this.dataService.addUserviewDetails(userval)
  .subscribe(result => {
  //console.log(result)
  this.userList=this.AESencrypt.decrypt(result);
  this.user=JSON.parse(this.userList);
  let count = 0;
  for (var db in this.user) {

     count = count + 1;

    }
    this.new=count;
   for (var i = 0; i < this.user.count; i++) {
  this.user.data.push(
      {
        id: i + 1,
        value: "items number " + (i + 1)
      }
    );
  }

  this.config = {
    itemsPerPage: 10,
   currentPage: 1,
    totalItems: this.user.count
  };
},

    error=>this.errorMsg=error
  );
}

pageChanged(event){
  this.config.currentPage = event;
}



onSelectionChange(entry) {

  this.selectedEntry = Object.assign({}, this.selectedEntry, entry);

this.newtime=this.selectedEntry.merchantId;
//console.log(this.newtime);
 this.showtime=this.AESencrypt.encrypt(this.newtime);
  var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1= Math.random();
  sessionStorage.setItem(tabID1,JSON.stringify(this.showtime));
//var noon=sessionStorage.getItem(tabID1);
//var klo=this.AESencrypt.decrypt(JSON.parse(noon));


}
changeEvent(event) {
  if (event.target.checked) {
      this.toggleBool= false;
  }
  else {
      this.toggleBool= true;
  }
}

 

  ngOnInit() {
    
  }

}
