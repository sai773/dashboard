import { TestBed } from '@angular/core/testing';

import { EncryptdecryptService } from './encryptdecrypt.service';

describe('EncryptdecryptService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EncryptdecryptService = TestBed.get(EncryptdecryptService);
    expect(service).toBeTruthy();
  });
});
