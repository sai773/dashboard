import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewaccontComponent } from './viewaccont.component';

describe('ViewaccontComponent', () => {
  let component: ViewaccontComponent;
  let fixture: ComponentFixture<ViewaccontComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewaccontComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewaccontComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
