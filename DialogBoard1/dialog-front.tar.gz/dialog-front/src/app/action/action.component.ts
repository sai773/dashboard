import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { EncryptdecryptService} from '../encryptdecrypt.service'
import { UserDetails, UserService, Users, Userrr,use1 } from '../User';
import { HttpClient } from  '@angular/common/http';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css']
})
export class ActionComponent implements OnInit {
  public leave:string;
  public new1:string;
  public leave1:string;
  public new11:string;
  public newcome:any;
  public newcome1:any;
  public newmerchant:any;
  public errorMsg;
  public showtime:any;
  public klo:any;
  public user:any;
  arr:any[] = [];
  public selectedval:any={};
  selectdata:UserService[]=[];


  readioSelected:any;
  showcontent:boolean=false;
  public entries = [];
  public selectedEntry;

  public newbolt:any;
  public newbolt1:any;

  public hlo1:any;
  toggleBool: boolean=true;



  config: any;
  collection = { count: 100000, data: [] };

  constructor(private dataService : DataService,private http: HttpClient,public router: Router,public ActivatedRoute:ActivatedRoute,private AESencrypt: EncryptdecryptService) {
  

var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1= Math.random();
this.showtime=sessionStorage.getItem(tabID1);
this.klo=this.AESencrypt.decrypt(JSON.parse(this.showtime));


var tabID3 = sessionStorage.tabID3 ? sessionStorage.tabID3 : sessionStorage.tabID3 = Math.random();
this.newcome=sessionStorage.getItem(tabID3);
this.newcome1=this.AESencrypt.decrypt(JSON.parse(this.newcome));


var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
this.newbolt= sessionStorage.getItem(tabID8);
this.newbolt1=this.AESencrypt.decrypt(JSON.parse(this.newbolt));



 
 let userval: use1={
  log2:this.AESencrypt.encrypt(this.klo),
      }
 this.dataService.addusenameDetails(userval).subscribe(users=>{
  this.newmerchant=this.AESencrypt.decrypt(users);
//console.log(this.newmerchant);
this.user=JSON.parse(this.newmerchant);


for(let dbdata of this.user)
{
if(dbdata.merchantId==this.klo)
{
  this.arr.push(dbdata);
//console.log
  this.selectdata=this.arr;
 //console.log(this.selectdata);
 let count = 0;
  for (var db in this.selectdata) {

     count = count + 1;

    }
    this.hlo1=count;
  //console.log(this.hlo1);
}
}
for (var i = 0; i < this.user.count; i++) {
  this.user.data.push(
      {
        id: i + 1,
        value: "items number " + (i + 1)
      }
    );
  }

  this.config = {
    itemsPerPage: 10,
    currentPage: 1,
    totalItems: this.user.count
  };





 },
    error=>this.errorMsg=error
  );
}
 
pageChanged(event){
  this.config.currentPage = event;
}




onSelectionChange(entry) {

  this.selectedEntry = Object.assign({}, this.selectedEntry, entry);

 this.showtime=this.AESencrypt.encrypt(this.selectedEntry.ServiceName);
  var tabID4= sessionStorage.tabID4 ? sessionStorage.tabID4 : sessionStorage.tabID4= Math.random();
  sessionStorage.setItem(tabID4,JSON.stringify(this.showtime));
//var noon=sessionStorage.getItem(tabID1);
//var klo=this.AESencrypt.decrypt(JSON.parse(noon));

}
changeEvent(event) {
  if (event.target.checked) {
      this.toggleBool= false;
  }
  else {
      this.toggleBool= true;
  }
}
  
  ngOnInit() {
  }

}
