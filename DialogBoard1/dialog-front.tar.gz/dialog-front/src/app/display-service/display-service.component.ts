import { Component, OnInit } from '@angular/core';
import { UserDetails, UserService,serv, Users } from '../User';
import { Http, Response, Headers, HttpModule} from '@angular/http';
import { DataService } from '../data.service';
import {ActivatedRoute} from '@angular/router';
import { Router} from '@angular/router';
import { findReadVarNames } from '@angular/compiler/src/output/output_ast';
import { EncryptdecryptService } from '../encryptdecrypt.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-display-service',
  templateUrl: './display-service.component.html',
  styleUrls: ['./display-service.component.css']
})
export class DisplayServiceComponent implements OnInit {
//  public onChange(event): void {  // event will give you full breif of action
  //  const newVal = event.target.value;
  //  console.log(newVal);
  //}
  public a:any;
  public selectedval:any={};
  selectdata:UserService[]=[];
  public select:any;
  public newleave:any;
  public userList:any;
  public user:any;
  //public    merchantId:String;
  public a1:any;
  public newleave1:any;
  arr:any[] = [];
  public modifiedtext:String;
  public errorMsg;
public newid:any;
public newid1:any;
public newl:any;


  public newcome:any;
  public newcome1:any;
  public showtime:any;
  public klo:any;


  public merchantId:any;
  public ServiceName:any;
  public ServiceDesc:any;
  public ServiceType:any;
  public  Country:any;
  public txtAccessperiod:any;
  public ddlAccessperiod:any;
  public  ddlFallbackpr1:any;
  public txtFallbackperiod1:any;
  public ddlFallbackperiod1:any;
 
  public  ddlFallbackpr2:any;
  public txtFallbackperiod2:any;
  public ddlFallbackperiod2:any;


  public txtfreetrail:any;
  public ddlfreetrailperiod:any;
  public ddlTps:any;

  public ServiceimgUrl:any;
  public RedirectionUrl: any;
  public CallbackUrl:any;
  public  SerValidationUrl: any;
  public  SerUnSubSCode:any;
  public SerUnsubId:any;
  public MHelplineno:any;
  public MSupEmailid:any;
  public ReceiptMessage:any;
  public WelcomeMessage:any;
  public  NotificationMessage:any;
  public  ServiceRoutingSettings:any;
  public  UnSubMessage:any;
public id1:any;
  public consumerkey:any;
  public consumerkey1:any;
  public merchantName:any;

  public newbolt:any;
  public newbolt1:any;



  constructor(private dataService : DataService,private http: HttpClient,public router: Router,public ActivatedRoute:ActivatedRoute , private AESencrypt: EncryptdecryptService ) {
 
var tabID1 = sessionStorage.tabID1 ? sessionStorage.tabID1 : sessionStorage.tabID1= Math.random();
this.showtime=sessionStorage.getItem(tabID1);
this.klo=this.AESencrypt.decrypt(JSON.parse(this.showtime));


 var tabID4= sessionStorage.tabID4 ? sessionStorage.tabID4 : sessionStorage.tabID4= Math.random();
this.newid=sessionStorage.getItem(tabID4);
this.newid1=this.AESencrypt.decrypt(JSON.parse(this.newid));

  var tabID8 = sessionStorage.tabID8 ? sessionStorage.tabID8 : sessionStorage.tabID8 = Math.random();
  this.newbolt= sessionStorage.getItem(tabID8);
  this.newbolt1=this.AESencrypt.decrypt(JSON.parse(this.newbolt));

  
  let userval: serv={
      log2:this.AESencrypt.encrypt(this.klo),
          
             }
       this.dataService.addservDetails(userval).subscribe(users=>{

      this.userList=this.AESencrypt.decrypt(users);
       this.user=JSON.parse(this.userList);
   
 
  for(let dbdata of this.user){

     if(this.newid1==dbdata.ServiceName){
     //  console.log(dbdata.ServiceName);
   this.select=this.arr.push(dbdata);
     //
        this.id1=dbdata._id;

        this.merchantId=dbdata.merchantId;
        this.ServiceName=dbdata.ServiceName;
       this.ServiceDesc=dbdata.ServiceDesc;
       this.ServiceType=dbdata.ServiceType;
        this.Country=JSON.parse(dbdata.Country);
       /// console.log(this.Country);
        this.txtAccessperiod=JSON.parse(dbdata.txtAccessperiod);
        this.ddlAccessperiod=dbdata.ddlAccessperiod;
     // console.log(this.ddlFallbackpr1);
        this.ddlFallbackpr1=JSON.parse(dbdata.ddlFallbackpr1);
        this.txtFallbackperiod1=dbdata.txtFallbackperiod1;
        this.ddlFallbackperiod1=dbdata.ddlFallbackperiod1;
       //console.log(this.ddlFallbackpr2);
        this.ddlFallbackpr2=JSON.parse(dbdata.ddlFallbackpr2);
        this.txtFallbackperiod2=JSON.parse(dbdata.txtFallbackperiod2);
        this.ddlFallbackperiod2=JSON.parse(dbdata.ddlFallbackperiod2);
 
   //   console.log(this.ddlFallbackperiod2);
        this.txtfreetrail=JSON.parse(dbdata.txtfreetrail);
        this.ddlfreetrailperiod=JSON.parse(dbdata.ddlfreetrailperiod);
        this.ddlTps=JSON.parse(dbdata.ddlTps);
    //console.log(this.ddlTps);
        this.ServiceimgUrl=dbdata.ServiceimgUrl;
        //console.log(this.RedirectionUrl);
        this.RedirectionUrl=dbdata.RedirectionUrl;
        this.CallbackUrl=dbdata.CallbackUrl;
        this.SerValidationUrl=dbdata.SerValidationUrl;
        this.SerUnSubSCode=dbdata.SerUnSubSCode;
        this.SerUnsubId=dbdata.SerUnsubId;
        this.MHelplineno=dbdata.MHelplineno;
        this.MSupEmailid=dbdata.MSupEmailid;
        this.ReceiptMessage=dbdata.ReceiptMessage;
        this.WelcomeMessage=dbdata.WelcomeMessage;
        this.NotificationMessage=dbdata.NotificationMessage;
        this.ServiceRoutingSettings=dbdata.ServiceRoutingSettings;
 
       this.UnSubMessage=dbdata.UnSubMessage;
     
       this.consumerkey=dbdata.consumerkey;
       this.consumerkey1=dbdata.consumerkey1;
       this.merchantName=dbdata.merchantName;
// console.log(this.consumerkey);
 //console.log(this.consumerkey1);
 
  }



}


  },
  error=>this.errorMsg=error );
    
   }
  
   getCustomerssService(form){
 //    console.log(this.id1);
    let newUser: UserService={
     // log1:this.AESencrypt.encrypt(this.newleave1),
     log1:this.AESencrypt.encrypt(this.id1),
     log2:form.value.marchantid,
      
     log3:form.value.ServiceName,
      log4: form.value.ServiceDesc,
      log5:form.value.ServiceType,
      log6:this.AESencrypt.encrypt(JSON.stringify(form.value.Country)),
      log7:this.AESencrypt.encrypt(JSON.stringify(form.value.txtAccessperiod)),
     log8:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlAccessperiod)),

      log9:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackpr1)),
      log10:this.AESencrypt.encrypt(JSON.stringify(form.value.txtFallbackperiod1)),
      log12:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackperiod1)),

      log13:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackpr2)),
      log14:this.AESencrypt.encrypt(JSON.stringify(form.value.txtFallbackperiod2)),
      log15:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlFallbackperiod2)),


     log16:this.AESencrypt.encrypt(JSON.stringify(form.value.txtfreetrail)),
      log17:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlfreetrailperiod)),

     log18:this.AESencrypt.encrypt(JSON.stringify(form.value.ddlTps)),

     log19:this.AESencrypt.encrypt(form.value.ServiceimgUrl),
      log20:this.AESencrypt.encrypt(form.value.RedirectionUrl),
     log21:this.AESencrypt.encrypt(form.value.CallbackUrl),
     log22:this.AESencrypt.encrypt(form.value.SerValidationUrl),
      log23:this.AESencrypt.encrypt(form.value.SerUnSubSCode),
      log24:this.AESencrypt.encrypt(form.value.SerUnsubId),
     log25:this.AESencrypt.encrypt(form.value.MHelplineno),
      log26:this.AESencrypt.encrypt(form.value.MSupEmailid),
     log27:this.AESencrypt.encrypt(form.value.ReceiptMessage),
      log28:this.AESencrypt.encrypt(form.value.WelcomeMessage),
     log29:this.AESencrypt.encrypt(form.value.NotificationMessage),

      log30:this.AESencrypt.encrypt(form.value.UnSubMessage),

      log31:this.AESencrypt.encrypt(form.value.ServiceRoutingSettings),
   
      log32:form.value.consumerkey,
      log33:form.value.consumerkey,
      log34:form.value.consumerkey,
    }
    this.dataService.updateCustomerService(newUser)
    .subscribe(result => {
    this.newl=result;
    //console.log(result);
    if(this.newl==true)
    {
      this.router.navigate(['/action'])

    }else{
     
    
    }
    },
    error=>this.errorMsg=error
    );
    
  }
 

 






  
  
  ngOnInit() {
    
  }


}
